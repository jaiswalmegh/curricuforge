from flask import Flask, render_template, request
from openai import OpenAI
import os

app = Flask(__name__)

client = OpenAI(
    api_key="your_api_here",  # Replace with your actual API key
    base_url="https://api.groq.com/openai/v1"
)

def generate_curriculum(skill, level, semesters, industry):
    prompt = f"""
You are a senior academic curriculum architect and industry advisor.

Design a DEEP, UNIVERSITY-LEVEL, SEMESTER-WISE curriculum that is:
- Academically rigorous
- Industry-aligned
- Progressively structured
- Suitable for real-world job readiness

INPUT DETAILS:
Skill Domain: {skill}
Student Level: {level}
Total Semesters: {semesters}
Industry Focus: {industry}

IMPORTANT STRUCTURE RULES:
1. Clearly separate each semester.
2. Make semester titles PROMINENT and descriptive.
3. Inside each semester, clearly label sections.
4. Emphasize CORE subjects and PRACTICAL components.
5. Show progression from fundamentals to advanced topics.
6. Avoid generic or shallow descriptions.

FOR EACH SEMESTER, STRICTLY INCLUDE:

SEMESTER TITLE

A. Core Subjects  
B. Practical / Labs / Projects  
C. Learning Outcomes  
D. Industry Relevance
"""

    response = client.chat.completions.create(
        model="llama-3.1-8b-instant",
        messages=[
            {"role": "system", "content": "You are an expert curriculum designer."},
            {"role": "user", "content": prompt}
        ],
        temperature=0.4
    )

    return response.choices[0].message.content


@app.route("/", methods=["GET", "POST"])
def index():
    curriculum = None
    error = None

    if request.method == "POST":
        try:
            skill = request.form["skill"]
            level = request.form["level"]
            semesters = request.form["semesters"]
            industry = request.form["industry"]

            curriculum = generate_curriculum(skill, level, semesters, industry)

        except Exception as e:
            error = str(e)

    return render_template("index.html", curriculum=curriculum, error=error)


if __name__ == "__main__":
    app.run(debug=True)
