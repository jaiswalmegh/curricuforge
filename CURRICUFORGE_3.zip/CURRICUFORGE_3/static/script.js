// CurricuForge – Loading animation controller
// Backend logic untouched

document.addEventListener("DOMContentLoaded", () => {
    const form = document.getElementById("curriculum-form");
    const loading = document.getElementById("loading-screen");

    if (form) {
        form.addEventListener("submit", () => {
            loading.classList.remove("hidden");
        });
    }
});
